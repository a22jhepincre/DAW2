<?php $__env->startSection('page-style'); ?>
    <style>
        .gradient-custom-2 {
            /* fallback for old browsers */
            background: #fccb90;

            /* Chrome 10-25, Safari 5.1-6 */
            background: -webkit-linear-gradient(to right, #ee7724, #d8363a, #dd3675, #b44593);

            /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
            background: linear-gradient(to right, #ee7724, #d8363a, #dd3675, #b44593);
        }

        .card-body {
            height: calc(100% - 56px);
            overflow-y: auto; /* Habilita el scroll vertical */
            scrollbar-width: thin; /* Para navegadores Firefox */
            scrollbar-color: #d3d3d3 #f1f1f1; /* Color del scrollbar */
        }

        .card-body::-webkit-scrollbar {
            width: 8px; /* Ancho del scrollbar */
        }

        .card-body::-webkit-scrollbar-track {
            background: #f1f1f1; /* Color de fondo del track del scrollbar */
            border-radius: 10px; /* Bordes redondeados del track */
        }

        .card-body::-webkit-scrollbar-thumb {
            background: #d3d3d3; /* Color del scrollbar (gris claro) */
            border-radius: 10px; /* Bordes redondeados del thumb */
        }

        .card-body::-webkit-scrollbar-thumb:hover {
            background: #b0b0b0; /* Color del scrollbar al pasar el mouse (gris más oscuro) */
        }


    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand-lg bg-body-tertiary gradient-custom-2">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/lotus.webp" style="width: 80px;" alt="logo">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav w-100">
                    <li class="nav-item w-100 text-center">
                        <a class="nav-link text-white fw-bold fs-3" href="javascript:;">
                            ¡Hello <?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>!
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="javascript:;" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-fill fs-3 text-white"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end"> <!-- Aquí se añade dropdown-menu-end -->
                            <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Log out</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <div class="p-4">
        <div class="row">
            <button id="btn-add-category"
                    class="card col-lg-3 col-12 me-lg-4 me-2"
                    style="height: 400px;width: 350px; background-color: #d5d5d5">
                <div class="card-body d-flex justify-content-center align-items-center w-100">
                    <i class="bi bi-plus-circle fs-3" style="color: #9b9b9b"></i>
                </div>
            </button>

            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="javascript:;" class="card col-lg-3 col-12 me-lg-4 me-2 text-decoration-none p-0" style="height: 400px; width: 350px;">
                    <div class="card-header bg-white d-flex justify-content-between">
                        <h4 class="card-title m-0 w-50">
                            <?php echo e($category->name); ?>

                        </h4>
                        <form id="delete-category-form-<?php echo e($category->id); ?>" method="POST" action="<?php echo e(route('category.delete', ['id' => $category->id])); ?>" class="d-none">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        </form>
                        <div>
                            <button class="btn gradient-custom-2 btn-sm btn-add-note" data-id-category="<?php echo e($category->id); ?>">
                                <i class="bi bi-plus text-white"></i>
                            </button>
                            <button class="btn gradient-custom-2 btn-sm btn-edit-category"
                                    data-id-category="<?php echo e($category->id); ?>"
                                    data-name-category="<?php echo e($category->name); ?>">
                                <i class="bi bi-pencil-square text-white"></i>
                            </button>
                            <button class="btn gradient-custom-2 btn-sm btn-delete-category"
                                    data-id-category="<?php echo e($category->id); ?>">
                                <i class="bi bi-trash text-white"></i>
                            </button>
                        </div>

                    </div>
                    <div class="card-body" style="height: calc(100% - 56px); overflow-y: auto;">
                        <?php $__empty_2 = true; $__currentLoopData = $category->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <div class="card mb-2" id="note-<?php echo e($note->id); ?>">
                                <div class="card-body d-flex justify-content-between">
                                    <div>
                                        <p class="fs-6 fw-bold m-0"><?php echo e($note->title); ?></p>
                                        <p class="fs-8 m-0"><?php echo e($note->description); ?></p>
                                    </div>

                                    <div>
                                        <button class="btn btn-sm btn-secondary btn-edit-note"
                                                data-id-category="<?php echo e($category->id); ?>"
                                                data-id-note="<?php echo e($note->id); ?>"
                                                data-title-note="<?php echo e($note->title); ?>"
                                                data-description-note="<?php echo e($note->description); ?>"
                                                ><i class="bi bi-pencil-square"></i></button>

                                        <form id="delete-note-form-<?php echo e($note->id); ?>" method="POST" action="<?php echo e(route('note.delete', ['id' => $note->id])); ?>" class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                        <button class="btn btn-sm btn-danger btn-delete-note"
                                                data-id-category="<?php echo e($category->id); ?>"
                                                data-id-note="<?php echo e($note->id); ?>"
                                                ><i class="bi bi-trash"></i></button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <div class="card-body d-flex justify-content-center align-items-center">
                                <p>No hay notas registradas.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-modal'); ?>
    <div class="modal fade" id="modal-category" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Nueva Categoria</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="form-category"
                        action="<?php echo e(route('category.store')); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <input value="" id="id-category" name="id" hidden/>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="bi bi-book"></i></span>
                            <input type="text" class="form-control" name="name" id="name" aria-label="Username" aria-describedby="basic-addon1">
                        </div>

                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-note" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">New Note</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="form-note"
                        action="<?php echo e(route('note.store')); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>

                        <input value="" id="idCategory" name="idCategory" hidden/>
                        <input value="" id="idNote" name="id" hidden/>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="bi bi-book"></i></span>
                            <input type="text" class="form-control" name="title" id="title" aria-label="Username" aria-describedby="basic-addon1">
                        </div>

                        <div class="input-group mb-3">
                            <textarea class="form-control" name="description" id="description" aria-label="Description" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('cate/index.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mati/Documentos/DAW2/M07/actividad_todoAEA21/resources/views/Category/category.blade.php ENDPATH**/ ?>