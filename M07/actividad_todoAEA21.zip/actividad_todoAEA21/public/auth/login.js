
//declarar variables

//funcion init donde busca en el documento las variables
function init(){
}


//funciones


//event listener para cargar todas las funciones creadas
document.addEventListener('DOMContentLoaded', function (){
    init();

});
